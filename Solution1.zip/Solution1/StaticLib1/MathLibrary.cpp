#include "pch.h"
#include "MathLibrary.h"

int calcPerimeter(int a, int b, int c) {
	return a + b + c;
}

float calcPlot(float a, float h) {
	return (a + h) / 2;
}