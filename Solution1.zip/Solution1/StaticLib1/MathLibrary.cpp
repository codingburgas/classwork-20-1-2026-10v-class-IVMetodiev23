#include "pch.h"
#include "MathLibrary.h"

void foo() {
	cout << "Hello, world!";
}

