#pragma once

void foo();