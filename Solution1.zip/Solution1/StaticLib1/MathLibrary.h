#pragma once

int calcPerimeter(int, int, int);
float calcPlot(float, float);