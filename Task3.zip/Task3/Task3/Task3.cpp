#include "../math/addition.h"
#include "../math/substraction.h"
#include "../math/multiplication.h"
#include "../math/division.h"
#include <iostream>
using namespace std;

int main() {
	cout << add(30, 5) << endl;
	cout << substract(35, 30) << endl;
	cout << multiply(5, 6) << endl;
	cout << divide(30, 6) << endl;
}
