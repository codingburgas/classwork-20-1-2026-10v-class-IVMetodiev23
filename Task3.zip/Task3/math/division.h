#pragma once
float divide(float, float);