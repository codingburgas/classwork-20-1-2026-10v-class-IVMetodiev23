#include "multiplication.h"

float multiply(float a, float b)
{
    return a * b;
}
