#include "substraction.h"

float substract(float a, float b)
{
    return a - b;
}
