#include "addition.h"

float add(float a, float b)
{
    return a + b;
}
