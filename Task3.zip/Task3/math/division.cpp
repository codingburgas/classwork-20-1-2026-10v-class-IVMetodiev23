#include "division.h"

float divide(float a, float b)
{
    return a / b;
}
