#pragma once
float add(float, float);