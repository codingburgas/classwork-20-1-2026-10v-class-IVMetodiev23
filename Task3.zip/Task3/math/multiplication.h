#pragma once
float multiply(float, float);