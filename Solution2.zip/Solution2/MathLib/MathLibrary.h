#pragma once

int calcPerimeter(int, int, int);
int calcPlot(int, int);