#include "MathLibrary.h"

int calcPerimeter(int a, int b, int c) {
	return a + b + c;
}

int calcPlot(int a, int h) {
	return (a * h) / 2;
}