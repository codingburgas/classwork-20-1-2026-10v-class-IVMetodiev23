#include <iostream>
#include "../MathLib/MathLibrary.h"
using namespace std;

int main() {
	cout << calcPerimeter(2, 3, 4) << endl;
	cout << calcPlot(5, 8) << endl;
}